package br.com.Passagens.aplicacao;
import br.com.Passagens.dao.VooDAO;
import br.com.Passagens.model.Voo;

public class Main {

	public static void main(String[] args) {
		
		VooDAO vooDao = new VooDAO();
		Voo voo = new Voo();
		voo.setDestino("Saubara / BJ");
		voo.setDatavoo("2020-09-06");
		voo.setCompanhia("Gol");
		vooDao.save(voo);
		
		//ATUALIZAR O CONTATO
		Voo c1 = new Voo();
		c1.setDestino("Saubara / BJ");
		c1.setDatavoo("2020-02-25");
		c1.setCompanhia("Azul");
		c1.setId(0);
	    //vooDao.update(c1);
		
		//DELETAR O CONTATO PELO SEU ID
		//vooDao.deleteByID(8);
		
		//VIZUALIZAÇÃO DOS REGISTROS DO BANCO DE DADOS TODOS
		for(Voo c : vooDao.getVoo()) {
			System.out.println("Voo: " + c.getDestino());
			
		}
	}
}

package br.com.Passagens.dao;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import br.com.Passagens.Factory.ConnectionFactory;
import br.com.Passagens.model.Voo;



public class VooDAO {

	public void save(Voo voo) {

		
		String sql = "INSERT INTO voos (Destino, Companhia, Datavoo) VALUES (?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//CRIAR UMA CONEXÃO COM O BANCO DE DAOS
			conn = ConnectionFactory.createConnectionToMySQL();
			
			//CRIAMOS UMA PREPAREDSTATEMENT, PARA EXECUTAR UMA QUERY
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			//ADICIONAR OS VALORES QUE SÃO ESPERADOS PELA QUERY
			pstm.setString(1, voo.getDestino());
			pstm.setString(3, voo.getDatavoo());
			pstm.setString(2, voo.getCompanhia());
			
			//EXECUTAR A QUERY
			pstm.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
		
			//FECHAR AS CONEXÕES
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		System.out.println("Cadastro salvo com sucesso!");
		}
	}

	public void update(Voo voo) {
		
		String sql = "UPTADE Voos SET Destino = ?, DataVoo = ?, Companhia = ? "+
				"WHERE id = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//CRIAR CONEXÃO COM O BANCO
			conn = ConnectionFactory.createConnectionToMySQL();
			
			//CRIAR A CLASSE PARA EXECUTAR A QUERY
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			//ADICIONAR OS VALORES PARA ATUALIZAR
			pstm.setString(1, voo.getDestino());
			pstm.setString(3, voo.getDatavoo());
			pstm.setString(2, voo.getCompanhia());
			
			//QUAL O ID DO REGISTRO QUE DESEJA ATUALIZAR
			pstm.setInt(4, voo.getId());
			
			//EXECUTAR A QUERY
			pstm.execute();
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm!=null) {
					pstm.close();
				}
				if (conn!=null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteByID(int Id_voo) {
		
		String sql = "DELETE FROM voos WHERE Id_voo = ?"; 
		
		Connection conn = null;
		
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			pstm.setInt(1, Id_voo);
			
			pstm.execute();
			
			System.out.println("Cadastro deletado com sucesso!");
		}catch (Exception e ) {
			e.printStackTrace();
		}finally {
			try {
				if(pstm!=null) {
					pstm.close();
				}
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	public List<Voo> getVoo(){
		
		String sql = "SELECT * FROM Voos";
		
		List<Voo> voos = new ArrayList<Voo>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		//CLASSE QUE VAI RECUPERAR OS DADOS DO BANCO
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				
				Voo voo = new Voo();
				
				//recuperar o id
				voo.setId(rset.getInt("Id_voo"));
				
				//recuperar o nome
				voo.setDestino(rset.getString("Destino"));
				
				//recuperar a data de cadastro
				voo.setDatavoo(rset.getString("Datavoo"));
				
				//recuperar a idade
				voo.setCompanhia(rset.getString("Companhia"));
				
				voos.add(voo);
			}	
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rset!=null) {
					rset.close();
				}
				if(pstm!=null) {
					pstm.close();
				}
				if(conn!=null) {
					conn.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return voos;
	}	
}

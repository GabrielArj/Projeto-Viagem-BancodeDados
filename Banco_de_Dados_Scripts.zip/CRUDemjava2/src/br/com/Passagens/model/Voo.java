package br.com.Passagens.model;
public class Voo {

	private int Id_voo;
	private String Destino;
	private String Companhia;
	private String Datavoo;

	
	public int getId() {
		return Id_voo;
	}
	public void setId(int Id_voo) {
		this.Id_voo = Id_voo;
	}
	
	
	
	public String getDestino() {
		return Destino;
	}
	public void setDestino(String destino) {
		this.Destino = destino;
	}
	
	
	public String getCompanhia() {
		return Companhia;
	}
	public void setCompanhia(String companhia) {
		this.Companhia = companhia;
	}
	
	
	
	public String getDatavoo() {
		return Datavoo;
	}
	public void setDatavoo(String Datavoo) {
		this.Datavoo = Datavoo;
	}


}

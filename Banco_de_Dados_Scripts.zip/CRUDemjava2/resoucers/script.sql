create database agenda;

create table contato(
id int not null auto_increment primary key,
nome varchar(100),
idade int, 
dataCadastro date
);